
let alienColor;
let alienScale;
let starX = [];
let starY = [];

function setup() {
  createCanvas(400, 400);

  let bleepbloop = [50, 100, 200, 300, 450];
  print(bleepbloop.length);

   // coloring
  alienShade = color(120, 180, 120);

   // scaling object
  alienSize = {
    sx: 1,
    sy: 1
  };

   // randomized stars
  for (let i = 0; i < 50; i++) {
    starX[i] = random(0, 400);
    starY[i] = random(0, 400);
  }

   // add tween
  p5.tween.manager
    .addTween(alienSize, "alienDance")

    // squish down
    .addMotions([
      { key: "sx", target: 1.5 },
      { key: "sy", target: 0.5 }
    ], 450, "easeOutQuad")

    // stretch up
    .addMotions([
      { key: "sx", target: 0.8 },
      { key: "sy", target: 1.2 }
    ], 450, "easeInOutQuad")

    // back to center
    .addMotions([
  { key: "sx", target: 1 },
  { key: "sy", target: 1 }
], 450, "easeInOutQuad")

    // repeat loop
    .startLoop();
}

function draw() {
  background(20, 0, 50);

  // title
  
fill(200, 80, 0);
textSize(25);
textStyle(BOLD);
textFont('monospace');
text("GALACTIC BREAKDANCE SOLO", 20, 35);
  
  // stars
  fill(255);
  noStroke();

  for (let i = 0; i < 50; i++) {
    circle(starX[i], starY[i], 3);
  }

  // alien placement
  push();
  translate(width / 2, 190);

  // tween scaling
 scale(alienSize.sx * 3, alienSize.sy * 3);

  drawAlien();

  pop();
}

  // alien construction function
function drawAlien() {

  // head
  noStroke();
  fill(alienShade);
  ellipse(0, 0, 30, 25);

  // belly
  circle(0, 15, 20);

  // handsies
  circle(-11, 13, 5);
  circle(11, 13, 5);

  // feetsies
  circle(-5, 25, 7);
  circle(5, 25, 7);

  // eyes
  fill(20, 20, 45);
  circle(-7, 3, 7);
  circle(7, 3, 7);

  // mouth
  ellipse(0, 9, 3, 5);

  // antennae
  stroke(alienShade);
  strokeWeight(3);

  line(-8, -10, -13, -16);
  line(8, -10, 13, -16);
}