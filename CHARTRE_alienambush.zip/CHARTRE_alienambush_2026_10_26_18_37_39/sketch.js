function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
  print(HowManyAliens());
}
function draw() {
  background(20, 20, 45);

//decorative stars
  stroke(255,255,255);
  strokeWeight(4);
  point(25,50)
  point(50, 120);
  point(180,80);
  point(150, 300);
  strokeWeight(2);
  point(20, 320);
  point(50, 270);
  point(100,80);
  point(100, 340);
  point(250, 340);
  
//establishing alien
function drawAlien(alienColor) {
//head
  noStroke();
  fill(alienColor);
  ellipse(0, 0, 30, 25);

//belly
  circle(0, 15, 20);

//handsies
  circle(-11, 13, 5);
  circle(11, 13, 5);

//feetsies
  circle(-5, 25, 7);
  circle(5, 25, 7);

//eyes
  fill(20, 20, 45);
  circle(-7, 3, 7);
  circle(7, 3, 7);

//mouth
  ellipse(0, 9, 3, 5);

//antennae
  stroke(alienColor);
  strokeWeight(3);
  line(-8, -10, -13, -16);
  line(8, -10, 13, -16);
  noStroke();
}
//title
  noStroke();
  fill(160, 60, 0);
  textStyle(BOLD);
  textSize(20);
  textFont('monospace');
  text("SPACE INVADERS REBORN:", 75, 30);
  fill(255, 130, 50);
  textSize(27);
  text("ABOMINABLE ALIEN AMBUSH", 14, 380);

//alien color progression
  let alienColors = [
    [50, 80, 70],  
    [70, 100, 90],
    [100, 140, 110],
    [110, 160, 120],
    [140, 180, 140],
    [190, 210, 170],
    [220, 240, 190],
    ];
  
//alien for loop
  for (let i = 0; i < 7; i++) {
   push();

//move aliens
   translate(40 + i * 50, 175);

//bigger aliens!!
   scale(1.5 + i * 0.7);

//alien rotation
   rotate(i * 5);

//aliens change color
   drawAlien(alienColors[i]);

   pop();
  }
}
//value return
function HowManyAliens() {
  return 7;
}