let alienX = [];
let alienY = [];
let starX = [];
let starY = [];
let youX = 250;
let youY = 250;

function setup() {
createCanvas(400, 400);

  //star array values
let bleepbloop = [50, 100, 200, 300, 450];
print(bleepbloop.length);

  //scattered stars
for (let i = 0; i < 50; i++) {
starX[i] = random(0, 400);
starY[i] = random(0, 400);
  }

  //scattered aliens
for (let i = 0; i < 30; i++) {
alienX[i] = random(50, 550);
alienY[i] = random(100, 550);
}
}

function draw() {
//background
background(20, 20, 45);

  //scattered stars
fill(255);
noStroke();

for (let i = 0; i < 50; i++) {
circle(starX[i], starY[i], 3);
}

  //aliens moving
for (let i = 0; i < 20; i++) {
alienX[i] = alienX[i] + 1;

if (alienX[i] > 520) {
alienX[i] = -20;
}

    //alien construction
  //head
fill(50, 240, 120);
ellipse(alienX[i], alienY[i], 30, 25);

  //body
fill(50, 240, 120);
circle(alienX[i] - 0, alienY[i] + 15, 20);
circle(alienX[i] + 7, alienY[i] + 3, 7);

  //feetsies
circle(alienX[i] - 5, alienY[i] + 25, 7);
circle(alienX[i] + 5, alienY[i] + 25, 7);

  //handsies
circle(alienX[i] - 11, alienY[i] + 13, 5);
circle(alienX[i] + 11, alienY[i] + 13, 5);

  //eyes
fill(20, 20, 45);
circle(alienX[i] - 7, alienY[i] + 3, 7);
circle(alienX[i] + 7, alienY[i] + 3, 7);

  //mouth
fill(20, 20, 45);
ellipse(alienX[i] - 0, alienY[i] + 9, 3, 5);

  //antennae
stroke(50, 240, 120);
strokeWeight(3);
line(alienX[i] - 8, alienY[i] - 10,
  alienX[i] - 13, alienY[i] - 16);
line(alienX[i] + 8, alienY[i] - 10,
  alienX[i] + 13, alienY[i] - 16);
noStroke();
}
  
  //your very own alien
  
youX = mouseX;
youY = mouseY;

  //head
fill(185, 125, 225);
ellipse(youX, youY, 30, 25);

  //body
circle(youX, youY + 15, 20);
circle(youX + 7, youY + 3, 7);

  //feetsies
circle(youX - 5, youY + 25, 7);
circle(youX + 5, youY + 25, 7);

  //handsies
circle(youX - 11, youY + 13, 5);
circle(youX + 11, youY + 13, 5);

  //eyes
fill(20, 20, 45);
circle(youX - 7, youY + 3, 7);
circle(youX + 7, youY + 3, 7);

  //mouth
ellipse(youX, youY + 9, 3, 5);

  //antennae
stroke(185, 125, 225);
strokeWeight(3);
line(youX - 8, youY - 10,
   youX - 13, youY - 16);
line(youX + 8, youY - 10,
   youX + 13, youY - 16);
noStroke();
strokeWeight(1);

  //title text
fill(20, 20, 45);
rect(60, 10, 280, 20 );
fill(200, 80, 0);
textSize(15);
textStyle(BOLD);
textFont('monospace');
text("SPACE INVADERS REBORN:", 100, 30);
fill(255, 130, 50);
textSize(23);
text("THE GREAT ALIEN MIGRATION", 25, 55);
}